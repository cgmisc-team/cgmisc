##'@title Manhattan_plot
##'
##'@description Just a wrapper for plot.scan.gwaa with some additional functions: 
##'add bonferroni threshold, plot only one chromosome or specific region, add inflation value. 
##'@param assoc
##'@param chr
##'@param infl
##'@param col
##'@param bonferroni
##'@param endPos
##'@param ymax

Manhattan_plot <- function(assoc, chr = NULL, infl = F, col=c("olivedrab", "slateblue4"), bonferroni=T, endPos = NULL, ymax = NULL, ...){
  if(is.null(ymax)){
    if(is.null(chr)){
      ymax <- -log10(summary(assoc)[1,"P1df"]) #The top p-value
    }else{
      ymax <- -log10(min(assoc[which(assoc[,1] == chr),"P1df"]))
    }
    
    if(bonferroni){
      threshold <- -log10(0.05/dim(assoc)[1])
      if(ymax < threshold){
        ymax <- threshold
      }    
    }
  }
  
  if(is.null(chr)){
    plot(assoc, pch=19, cex=0.5, ylim=c(0, ymax), col=col, ...)
  }else{
    if(!is.null(endPos)){
      pos <- assoc@annotation$Position[assoc@annotation$Chromosome == chr
                                       & assoc@annotation$Position > endPos[1] 
                                       & assoc@annotation$Position < endPos[2]]
      pval <- -log10(assoc@results$P1df[assoc@annotation$Chromosome == chr 
                                        & assoc@annotation$Position > endPos[1] 
                                        & assoc@annotation$Position < endPos[2]])
      plot(pos, pval, pch=19, cex=0.5, ylab=expression(paste("-", log[10], "(p-value)", sep="")), xlab="position (bp)", ylim=c(0, ymax), ...)
    }else{
      plot(assoc[which(assoc[,1] == chr),"Position"], -log10(assoc[which(assoc[,1] == chr),"P1df"]), 
           pch=19, cex=0.5, ylab=expression(paste("-", log[10], "(p-value)", sep="")), xlab="position (bp)", ylim=c(0, ymax), ...)
      #mtext(paste("Chromosome", chr))
    }
  }
  
  if(infl){
    inflation <- estlambda(assoc[,"P1df"])
    mtext(paste("lambda = ", round(inflation$estimate, digits=3), sep=""))
  }
  if(bonferroni){
    abline(h=threshold, col="darkgoldenrod", lty=2)
  }
}
