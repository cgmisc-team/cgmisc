#GWASdata=data.qc1
#gwas.result=mm
#chr=1
#marker1= 'BICF2S23619811'
#marker2 = 'BICF2P425659'
#snps = c('BICF2S23619811', 'BICF2P425659')
#region = c(9450000,13950000)
#trait = 'X8b_phantom_control'
#recode = F
#returnBox = F
#returnGeno = F
#SNP.names = NULL
#legend = F
#legendPos = "topleft"

##'@title fitSNPs
##'@description Fits a linear model between one or several SNPs and the phenotype. Includes interactions if interaction = T. 
##'Can also return a correlation matrix of all the terms in the model.
##'@param GWASdata
##'@param snps
##'@param pheno
##'@param returnCor
##'@param interaction
##'@param geno
##'
##'

fitSNPs <- function(GWASdata, snps, pheno, returnCor = F, interaction = F, geno = NULL){
  if(is.null(geno)){
    geno <- as.double.gwaa.data(GWASdata[,snps])
  }
  pheno <- GWASdata@phdata[,pheno]
  if(interaction){
    data <- as.data.frame(cbind(pheno, geno))
    names(data)[1] <- "pheno"
    formula <- as.formula(paste("pheno", "~", paste(names(data)[2:length(names(data))], collapse="*")))
    model <- lm(formula, data=data)
  }
  else{
    model <- lm(pheno ~ geno)
  }
  if(returnCor){
    tmp <- summary(model)
    return(list(model = model, correlation = cov2cor(tmp$cov.unscaled)))
  }
  return(model)
}