##'@title SNP_box
##'
##'@description Makes boxplots of the individuals in every genotypic class, based on a SNP.
##' Works for both outbreed (three boxes) and inbreed (two boxes) data. 
##'@param GWASdata
##'@param marker
##'@param trait
##'@param returnBox
##'@param recode
##'

SNP_box <- function(GWASdata, marker, trait, returnBox = F, recode = F, ...){
  if(recode){
    geno <- as.double.gwaa.data(GWASdata[,marker])
    geno[geno[,1] == 0,1] <- "AA"
    geno[geno[,1] == 1,1] <- "Aa"
    geno[geno[,1] == 2,1] <- "aa"
  }else{
    geno <- as.genotype.gwaa.data(GWASdata[,marker])
  }
  y <- phdata(GWASdata)[,trait]
  box <- boxplot(y ~ as.matrix(geno), col = c('lightblue2','lightpink1','lightsalmon'))
  axis(1, at=1:length(box$n), labels=paste("n =", box$n), line=2, lty=0)
  
  #If there is only one genotype present, print it on the x-axis anyway
  genotypes <- as.character(unique(geno[,1]))
  if(length(genotypes) == 1){
    axis(1, at=1, labels=genotypes)
  }
  if(returnBox){
    return(box)
  }
}
