##'@title SNP_vioplot
##'
##'@description Kind of the same as SNP_box but makes violin plots instead.
##'@param GWASdata
##'@param SNP
##'@param trait
##'@param returnInd

SNP_vioplot <- function(GWASdata, SNP, trait, returnInd = F){
  if (!require(vioplot)) {
    stop("ERROR! Library vioplot couldn't be loaded.")
  }
  geno.allInd <- as.genotype.gwaa.data(GWASdata[,SNP])
  geno.uniq <- na.omit(unique(sort(geno.allInd[,1])))
  
  if(length(geno.uniq) == 1){
    x <- na.omit(phdata(GWASdata)[,trait])
    vioplot(x, names=geno.uniq, col="gold")
  } else if(length(geno.uniq) == 2){
    x.names <- rownames(geno.allInd)[geno.allInd[,1] == as.character(geno.uniq[1]) ]
    x <- na.omit(phdata(GWASdata)[phdata(GWASdata)[,"id"] %in% x.names, trait])
    y.names <- rownames(geno.allInd)[geno.allInd[,1] == as.character(geno.uniq[2]) ]
    y <- na.omit(phdata(GWASdata)[phdata(GWASdata)[,"id"] %in% y.names, trait])
    vioplot(x, y, names=geno.uniq, col="gold")
  } else if(length(geno.uniq) == 3){
    x.names <- rownames(geno.allInd)[geno.allInd[,1] == as.character(geno.uniq[1]) ]
    x <- na.omit(phdata(GWASdata)[phdata(GWASdata)[,"id"] %in% x.names, trait])
    y.names <- rownames(geno.allInd)[geno.allInd[,1] == as.character(geno.uniq[2]) ]
    y <- na.omit(phdata(GWASdata)[phdata(GWASdata)[,"id"] %in% y.names, trait])
    z.names <- rownames(geno.allInd)[geno.allInd[,1] == as.character(geno.uniq[3]) ]
    z <- na.omit(phdata(GWASdata)[phdata(GWASdata)[,"id"] %in% z.names, trait])
    vioplot(x, y, z, names=geno.uniq, col="gold")
  } else{
    print("Error: number of genotypes must in the range 1-3", quote=F)
    print(geno.uniq)
  }
  mtext(trait, side=2, line=2.5)
  if(returnInd){
    return(list( AA = x.names, Aa = y.names, aa = z.names))
  }
}
