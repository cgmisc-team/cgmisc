##'@title Identifies runs of homozygosity across chromosome.
##'@description Identifies runs of homozygosity across chromosome.
##'@author Marcin Kierczak <\email{Marcin.Kierczak@@imbim.uu.se}>, Jagoda Jablonska <\email{jagoda100jablonska@@gmail.com}>
##'@param data a gwaa.data class object as used by \code{\link[GenABEL]{gwaa.data-class}}
##'@param chr number of chromosome overlapping windows were produced from
##'@param LW a matrix of windows coordinares returned by \code{get.overlapping.windows} function
##'@param hetero.zyg a matrix of average heterozygosities for windows returned by \code{het.for.overlap.wind} function
##'@return bla
##'@seealso \code{\link[cgmisc]{get.overlapping.windows}}
##'@keywords heterozygosity, homozygosity, window 
##'
##'@export

ROHcpp  <- function (data, chr, LW, hetero_zyg) {
  ## calculating threshold for ROH
  gtype = data@gtdata
 # het.all  <- descriptives.marker(data)[[7]]
  n = gtype@nsnps - gtype@nids
  L = log(0.05/n) / log(1-0.65) #minimal number of SNPs
  threshold = 0.23
  library(Rcpp)
  
  ##cpp function
  
  sourceCpp('R/try.cpp')
  
  ## Identifying runs of homozygosity across the windows
  dist  <- as.data.frame(LW[1])
  logical  <- regions(hetero_zyg,0.21)
  logical <- unlist(logical)
  blocks  <- c(logical[1] == TRUE, diff(logical))
  runs  <- matrix(ncol = 4, nrow = 5000)
  colnms  <- c('window','begin','end','numb')
  colnames(runs) <- paste(colnms)
  index = 0
  i = 1
  while( i < length(blocks)) {
    if( blocks[i] == 1){
      index = index +1
      runs[index,1]  <- i
      runs[index,2]  <- dist[i,1]
      while (blocks[i] != -1){
        i = i+1
      }
      runs[index, 3]  <- dist[i-1,3]
      beg  <- runs[index,2]
      end  <- runs[index,3]
      nsnp  <- length(which(data@gtdata@chromosome == chr & data@gtdata@map > beg & data@gtdata@map < end ))
      nsnp -> runs[index,4]
      next
    } else {
      i = i+1
      next
    }     
  }
  runs  <-  runs[rowSums(is.na(runs)) != ncol(runs),]
  runs <- runs[which(runs[,'numb'] > L ),]
  return (runs)
}
