##'@title gwaa2varEffPred
##'
##'@description GenABEL-object to the format accepted by variant effect predictor
##'@param GWASdata
##'@param SNPs
##'

gwaa2varEffPred <- function(GWASdata, SNPs = NULL){
  if(!is.null(SNPs)){
    SNPsummary <- summary(GWASdata[,SNPs])
  }
  else{
    SNPsummary <- summary(GWASdata)
  }
  
  output <- matrix(nrow=nrow(SNPsummary), ncol=6)
  for(i in 1:nrow(SNPsummary)){
    snp <- SNPsummary[i,]
    chr <- as.character(snp$Chromosome)
    if(snp$A2 == "-"){
      output[i,] <- c(chr,snp$Position,(snp$Position + 1),paste(snp$A1, snp$A2, sep="/"),"+", "")
    }
    else{
      output[i,] <- c(chr,snp$Position,snp$Position,paste(snp$A1, snp$A2, sep="/"),"+", "")
    }
  }
  return(output)
}