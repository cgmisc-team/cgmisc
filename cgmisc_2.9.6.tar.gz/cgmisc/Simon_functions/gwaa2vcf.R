##'@title gwaa2vcf
##'
##'@description GenABEL-object to vcf-file
##'@param GWASdata
##'@param file
##'@param chr
##'@param endPos

gwaa2vcf <- function(GWASdata, file, chr = NULL, endPos = NULL){
  if(!(is.null(chr) & is.null(endPos))){
    region <- which(GWASdata@gtdata@chromosome == chr & map(GWASdata) > endPos[1] & map(GWASdata) < endPos[2])
    GWASdata <- GWASdata[,region]
  }
  GWASdata.sum <- summary(GWASdata)
  output <- cbind(GWASdata.sum[,1:2], rownames(GWASdata.sum), GWASdata.sum[4:5])
  
  write("##fileformat=VCFv4.1", file=file)
  write.table(t(c("#CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO")), file=file, append=T, quote=F, sep="\t", row.names=F, col.names=F)
  write.table(output, file=file, append=T, quote=F, sep="\t", row.names=F, col.names=F)
}