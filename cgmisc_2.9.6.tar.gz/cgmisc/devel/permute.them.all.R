##' @title Permutation tests 
##' 
##' @description Permutation tests
##' @author Marcin Kierczak <\email{Marcin.Kierczak@@imbim.uu.se}>
##' @param N number of iterations
##' @param h2h object returned by polygenic_hglm
##' @param data your data
##' @param pop vector with populations
##' @param progress if you want to print the progress bar
##' @return list of permuted p-values, corected p-values 
##' @examples
##'  \dontrun{permute.them.all(N = 10, h2h, data, pop, progress=T)
##'  }
##' @keywords permutations
##' @export


permute.them.all <- function(N = 10, h2h, data, pop, progress=T) {
  require(BBmisc)
  # Do permutations
  result <- c()
  result.c <- c()
  min_p <- c()
  min_pc <- c()
  if (progress) { bar <- makeProgressBar(min = 0, max =  N, label =  "\nProgress", char = "=") }
  for (i in seq(1, N)) {
    h2h$residualY <- sample(h2h$residualY) # Shuffle residuals
    mm.tmp <- mmscore(h2h, data, strata=pop, clambda=F)
    min_p <- c(min_p, min(mm.tmp[,"P1df"]))
    min_pc <- c(min_pc, min(mm.tmp[,"Pc1df"]))
    result <- rbind(result, sort(-log10(mm.tmp[,"P1df"])))
    result.c <- rbind(result.c, sort(-log10(mm.tmp[,"Pc1df"])))
    if (progress) { bar$inc(1) }
  }
  result <- list(min.p = min_p, min.pc = min_pc, result.p = result, result.pc = result.c)
  return(result)
}