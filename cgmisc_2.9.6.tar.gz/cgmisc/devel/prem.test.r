##' Performs permutations on GRAMMAR+-transformed mixed model residuals.
##'@description for details see: Belonogova NM et al. (2013). PloS ONE 8: e65395.
##'@param N number of permutation tests to perform
##'@param h2h an object returned by either polygenic or polygenic_hglm
##'@param data a gwaa.data class object
##'@param pop a vector assigning each individual to a population
##'@param progress a logical determining whether to show progress bar
##'@return a list containing four elements: a vector of minimal P1df values,
##' a vector of minimal Pc1df values, result - a vector of sorted -log10 of P1df and
##' result.c - a vector of sorted -log10 of Pc1df.
##' 
#num.cores = 3
#h2h = h2h
#data = data.qc1
#pop =pop
permute.them.all <- function(N , h2h, data, pop, num.cores=0) {
  require("BBmisc")
  require("snow")
  require('snowfall')
  # Do permutations
  result <- c()
  result.c <- c()
  min_p <- c()
  min_pc <- c()
  if (class(h2h) == 'polygenic_hglm') {
    warning("Object of class 'polygenic_hglm' supplied: pgresidualsY will be permuted instead of GRAMMAR-gamma-transformed residuals!")
  }
  
  permut <- function(N , h2h, data, pop) {
    require("GenABEL")
    for (i in 1:N) {
      if (class(h2h) == 'polygenic') {
        h2h$pgresidualY <- sample(h2h$grresidualY) # Shuffle residuals
      } else {
        h2h$pgresidualY <- sample(h2h$pgresidualY) # Shuffle residuals
      }
      mm.tmp <- mmscore(h2h, data, strata=pop, clambda=F)
      min_p <- c(min_p, min(mm.tmp[,"P1df"]))
      min_pc <- c(min_pc, min(mm.tmp[,"Pc1df"]))
      result <- rbind(result, sort(-log10(mm.tmp[,"P1df"])))
      result.c <- rbind(result.c, sort(-log10(mm.tmp[,"Pc1df"])))
      #print(paste(i,"..."))
      if (progress) {
        bar$inc(1)
      }
    }
    result <- list(min.p = min_p, min.pc = min_pc, result.p = result, result.pc = result.c)
    return(result)
  }
  return(res)
}

avail.cores <- detectCores()
if (num.cores > avail.cores || num.cores <= 0) {
  num.cores <- avail.cores - 1
}
N.runs <- ceiling(N/num.cores)
cl  <- makeCluster(num.cores, type = 'SOCK')
clusterEvalQ(cl, library("GenABEL", "stats"))
.env <- environment()
clusterExport(cl, list('N','h2h', 'data', 'pop'), envir = .env)
res <- clusterCall(cl, eval, permut(N, h2h, data, pop))
stopCluster(cl)
