##'@title Get mean values for windows.
##'@description Get mean values for windows.
##'@author Marcin Kierczak <\email{Marcin.Kierczak@@imbim.uu.se}>
##'@param LW a a matrix of logicals returned by \code{get.overlapping.windows} function
##'@param x a vector of some values per each marker
##'@return vector of means
##'@seealso \code{\link[cgmisc]{get.overlapping.windows}}
##'@keywords heterozygosity, window 
##'
##'@export
get.window.means <- function(x, LW) {
  X <- matrix(rep(x, times=nrow(LW)), nrow=nrow(LW), byrow=T)
  # The trick is to set all the values not-belonging to a window to NA and tell the mean() function
  # to skip the NAs
  X[LW == F] <- NA
  means <- apply(X, 1, mean, na.rm=T)
  return(means)
}
